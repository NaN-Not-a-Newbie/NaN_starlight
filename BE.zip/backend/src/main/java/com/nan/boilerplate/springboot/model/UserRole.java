package com.nan.boilerplate.springboot.model;


public enum UserRole {
    USER, ADMIN, STAFF, COMPANY
}
