package com.nan.boilerplate.springboot.model;

public enum SalaryType {
    // 시급, 주급, 월급, 연봉
    TIME, WEEK, MONTH, YEAR
}
