package com.nan.boilerplate.springboot.model;

public enum EnvLstnTalk {
    // 듣고 말하는 작업 어려움, 듣고 말하기에 어려움 없음, 간단한 듣고 말하기 가능, 무관
    HARD, NOPROBLEM, SIMPLETALLK, DONTCARE
}
