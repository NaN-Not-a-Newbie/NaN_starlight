package com.nan.boilerplate.springboot.model;


public enum Education {
    ELEM, MIDDLE, HIGH, UNIV, MASTER, DOCTOR,DONTCARE
}
