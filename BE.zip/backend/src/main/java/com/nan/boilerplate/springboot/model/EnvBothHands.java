package com.nan.boilerplate.springboot.model;

public enum EnvBothHands {
    // 한손작업 가능, 한손보조작업 가능,양손작업 가능, 무관
    ONE, SUBHAND, BOTHAND, DONTCARE
}
