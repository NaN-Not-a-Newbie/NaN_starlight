package com.nan.boilerplate.springboot.model;

public enum EnvHandWork {
    // 큰 물품 조립가능, 작은 물품 조립가능, 정밀한 작업가능, 무관
    BIG, SMALL, ACCURATE, DONTCARE
}
