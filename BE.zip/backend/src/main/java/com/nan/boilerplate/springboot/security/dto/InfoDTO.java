package com.nan.boilerplate.springboot.security.dto;

public interface InfoDTO {
}
