package com.nan.boilerplate.springboot.model;

public enum EnvLiftPower {
    // 5Kg 이내의 물건, 5~20Kg의 물건, 20Kg 이상의 물건을 다룰 수 있음, 무관
    UNDER5, UNDER20, OVER20, DONTCARE
}
