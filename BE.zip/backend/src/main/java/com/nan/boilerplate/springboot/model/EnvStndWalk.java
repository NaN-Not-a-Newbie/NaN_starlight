package com.nan.boilerplate.springboot.model;

public enum EnvStndWalk {
    // 오랫동안 가능, 서거나 걷는 일이 어려움, 일부 서서하는 작업 가능, 무관
    LONG, HARD, PART,  DONTCARE
}
