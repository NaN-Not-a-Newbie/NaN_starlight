package com.nan.boilerplate.springboot.model;

public enum EnvEyesight {
    // 아주 작은 글씨, 일상적활동, 비교적 큰 인쇄물, 무관
    VERYSMALLCHAR, ADL, BIGHAR, DONTCARE
}
